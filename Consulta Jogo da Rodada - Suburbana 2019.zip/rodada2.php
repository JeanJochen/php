<?php 
  $Rodada = $_POST[RODADA];

  $Link1 = "http://191.252.64.150/sisgol/DERW700B.asp?SelStart1=2019&SelStop1=2019&SelStart2=78&SelStop2=78&SelStart3=&SelStop3=";
  $Link2 = "&SelStart4=";
  $Link3 = $Rodada;
  $Link4 = "&SelStop4=";
  $Link5 = $Rodada;
  $Link6 = "&SelStart5=&SelStop5=&RunReport=Run+Report";


// monta link  
  $MontaLink = $Link1.$Link2.$Link3.$Link4.$Link5.$Link6;
 // print($MontaLink);

// redireciona p�gina para o link
header("Location: ".$MontaLink."");
?>